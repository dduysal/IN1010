public class MillitaerResepter extends HviteResepter {
  public MillitaerResepter(Legemiddel legemiddel, Lege utskrivendeLege, Pasient pasient, int reit) {
    super(legemiddel, utskrivendeLege, pasient, reit);
  }

  @Override
  public double prisAaBetale() {
    return 0;
  }




}
