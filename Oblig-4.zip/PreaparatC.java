public class PreaparatC extends Legemiddel {

  public PreaparatC(String navn, String type, double pris, double virkestoff) {
    super(navn, type, pris, virkestoff);
  }

  public String toString() {
    return super.toString();
  }
}
