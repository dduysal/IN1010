public class Stabel<T> extends Lenkeliste<T> {
  private int antall = 0;

  public Stabel() {
    super();
  }

  public int stoerrelseStabel() {
    return antall;
  }

@Override
  public void printAlle() {
    Node temp = foran;
    while(temp != null) {
      System.out.println(temp.data);
      temp = temp.neste;
    }
  }

  //legge til slutten av listen
  public void leggPaa(T x) {
    leggTil(x);
    antall++;
  }

  //ta av slutten av listen
  public T taAv() {
    if(stoerrelseStabel() == 0) {
      throw new UgyldigListeIndeks(-1);
    } else {
      antall--;
      return fjern(stoerrelseStabel());
    }

  }


} //end
