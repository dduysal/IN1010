public class BilBrukt3 {
  public static void main(String[] args) {
    Bil3 bil = new Bil3("BN1234");
    Person p = new Person(bil);
    p.skrivUt();
  }
}
