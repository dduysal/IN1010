import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;
import java.util.*;

public class Kryptert_Monitor {
  Lock laas = new ReentrantLock();
  Condition tilgang = laas.newCondition();

  ArrayList<Melding> alleMeldinger = new ArrayList<Melding>();

  public void settInnKryptertMonitor(Melding melding) {
    laas.lock();
    try {
      alleMeldinger.add(melding);
      tilgang.signalAll();
    }
       finally {
      laas.unlock();
    }
  }

  public Melding hentFraKryptertMonitor() {
    Melding m = null;
    laas.lock();
    try {
      while(alleMeldinger.isEmpty()) {
        tilgang.await();
      }
      m = alleMeldinger.remove(0);
      //System.out.println(m);
    } catch (InterruptedException n) { }
       finally {
        laas.unlock();
    }
    return m;
  }
}
