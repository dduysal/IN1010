import java.io.*;
import java.util.*;
public abstract class Rute {
  protected int r;
  protected int k;
  Labyrint lab;
  protected Rute nord, vest, sor, ost;
  private boolean besokt = false; //false når den ruteren ikke er bsøkt, true hvis den er besøkt


  public Rute(int r, int k, Labyrint lab) {
    this.r = r;
    this.k = k;
    this.lab = lab;
  }

  /*public void settNaboer() {
    System.out.println("Sette naboer " + toString());
    nord = koordinatNord(r, k);
    vest = koordinatVest(r, k);
    ost = koordinatOst(r, k);
    sor = koordinatSor(r, k);
    System.out.println("nord: " + nord);
    System.out.println("vest: " + vest);
    System.out.println("ost: " + ost);
    System.out.println("sor: " + sor);
  }*/

  public Rute koordinatNord(int posX, int posY) {
    try {
      if(lab.hentPos(posX-1, posY) == null) {
        return null;
      }

      nord = lab.hentPos(posX-1, posY);
      return nord;

    } catch(Exception a){};
    return nord;

  }

  public Rute koordinatSor(int posX, int posY) {
    try {
      if(lab.hentPos(posX+1, posY) == null) {
        return null;
      }
      sor = lab.hentPos(posX+1, posY);
      return sor;

    } catch(Exception a){};
    return sor;
  }

  public Rute koordinatVest(int posX, int posY) {
    try {
      if(lab.hentPos(posX, posY-1) == null) {
        return null;
      }
      vest = lab.hentPos(posX, posY-1);
      return vest;

    } catch(Exception a){};
    return vest;
  }

  public Rute koordinatOst(int posX, int posY) {
    try {
      if(lab.hentPos(posX, posY+1) == null) {
        return null;
      }
      ost = lab.hentPos(posX, posY+1);
      return ost;

    } catch(Exception a){};

    return ost;
  }

  public void gaa(String pos) {
    pos += "(" + (r) + ", " + (k) + ")";
    besokt = true;
    pos += "-->";
    if(koordinatNord(r, k) != null && !koordinatNord(r, k).besokt ) {
      koordinatNord(r, k).gaa(pos);
    }
    if(koordinatSor(r, k) != null && !koordinatSor(r, k).besokt ) {
      koordinatSor(r,k).gaa(pos);
    }
    if(koordinatOst(r, k) != null && !koordinatOst(r, k).besokt ) {
      koordinatOst(r,k).gaa(pos);
    }
    if(koordinatVest(r, k) != null && !koordinatVest(r, k).besokt ) { //&& this.tilTegn().equals(".")
      koordinatVest(r,k).gaa(pos);
    }
    besokt = false;
  }

  public void finnUtvei(){
    gaa("");
  }

  

  @Override
  public String toString() {
    return r + ", " + k + " - " + tilTegn();
  }

  //retunerer rutens tegnepresentasjon (filformatet)
  public abstract String tilTegn();
}
