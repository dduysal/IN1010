public class Aapning extends HvitRute {

  public Aapning(int r, int k, Labyrint lab) {
      super(r, k, lab);
    }

    public void gaa(String t) {
      if(lab.aapning(r, k , lab.hentR(), lab.hentK())) { //aapning lab.aapning(r, k, lab.hentR(), lab.hentK()) == true
        lab.settUtveier(t);
        System.out.println(t);
      }
    }
}
