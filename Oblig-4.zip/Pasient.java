public class Pasient {
  private String navn;
  private String fnr;
  private int pid;
  Stabel<Resept> reseptListe;

  public Pasient(String navn, String fnr, int pid) {
    this.navn = navn;
    this.fnr = fnr;
    this.pid = pid;
    reseptListe = new Stabel<Resept>();
  }

  public String hentNavn() {
    return navn;
  }

  public String hentFnr() {
    return fnr;
  }

  public int hentPid() {
    return pid;
  }

  public void leggTilResept(Resept r) {
    reseptListe.leggTil(r);
  }

  public Stabel<Resept> hentListe() {
    return reseptListe;
  }



  public String toString() {
    return "Pasient: " + hentNavn() + " Fødeselsnr: " + hentFnr() + "  PID: " + hentPid();
  }


}
