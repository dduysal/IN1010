public class BilBrukt2 {
  public static void main(String[] args){
    Bil2 b2 = new Bil2("BN1234");
    b2.skrivUt();
  }
}
