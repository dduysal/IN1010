public class P_Resepter extends HviteResepter {
  public P_Resepter(Legemiddel legemiddel, Lege utskrivendeLege, int pasientId, int reit) {
    super(legemiddel, utskrivendeLege, pasientId, reit);
    reit = 3;

  }

  public double prisAaBetaleP_Resepter() {
    double prisMRabatt = legemiddel.hentPris() - 108;
    if(prisMRabatt > 0) {
      return legemiddel.settNyPris(prisMRabatt);
    }
    return 0.0; //retunerern 0 hvis prisMRabatt er mindre enn 0
  }
}
