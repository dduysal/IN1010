public class HvitRute extends Rute {

public HvitRute(int r, int k, Labyrint lab) {
    super(r, k, lab);
  }

  //retunerer rutens tegnepresentasjon (filformatet)
  
  public String tilTegn() {
    return ".";
  }

}
