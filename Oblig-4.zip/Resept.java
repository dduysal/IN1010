public abstract class Resept {
  protected Legemiddel legemiddel;
  protected Lege utskrivendeLege;
  protected Pasient pasient;
  protected int reit;

  public Resept(Legemiddel legemiddel, Lege utskrivendeLege, Pasient pasient, int reit) {
    this.pasient = pasient;
    this.legemiddel = legemiddel;
    this.utskrivendeLege = utskrivendeLege;
    this.reit = reit;
  }

  public Legemiddel hentLegeMiddel() {
    return legemiddel;
  }

  public String hentType() {
    return legemiddel.hentType();
  }

  public double hentPrisFraLegeMiddel() {
    return prisAaBetale();
  }

  public Lege hentLege() {
    return utskrivendeLege;
  }

  public Pasient hentPasient() {
    return pasient;
  }

  public int hentReit() {
    return reit;
  }

  public boolean bruk() {
    if(reit <= 0) {
      return false;
    }
    return true;
  }

  public String toString() {
    return "Legemiddel: " + legemiddel.hentNavn() + ", UtskrivendeLege: " + utskrivendeLege.hentNavn() + ", pasient: " + hentPasient() + ", Reit: " + hentReit();
  }

  //for aa kunne implemntere en abstract metode kan man lage en subklasse og lage akkurat den samme metoden
  abstract public String farge();

  abstract public double prisAaBetale();

}
