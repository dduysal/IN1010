public class Rack {
  Node nodeliste [];
  int antNoder;

  public Rack(int antNoder) {
    nodeliste = new Node[antNoder];
  }

  public void settInnNode(Node n) {
    int maksNoder = nodeliste.length;
    for(int i = 0; i < nodeliste.length; i++) {
      if(maksNoder > i) {
        nodeliste[i] = n;
      } else {
        System.out.println("Det er fullt!!!");
      }
    }
  }


  public int hentAntNode() {
    return nodeliste.length;
  }


  public int antProsessorer() {
    int antall = 0;
    for(int i = 0; i < nodeliste.length; i++) {
      try {
        antall = nodeliste[i].hentAntProsessor() + antall;
      } catch(NullPointerException n) {};
    }
    return antall;
  }


  //Beregner antall noder i racket med minne over gitt grense
  public int noderMedNokMinne(int paakrevdMinne) {
    int teller = 0;
    for(int i = 0; i < nodeliste.length; i++) {
      try {
        if(nodeliste[i].hentminnestr() >= paakrevdMinne) {
          teller++;
        }
      } catch(NullPointerException n) {};
    }
    return teller;
  }



} //end of class
