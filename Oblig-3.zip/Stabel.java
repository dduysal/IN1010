public class Stabel<T> extends Lenkeliste<T> {

  public Stabel() {
    super();
  }

  //legge til slutten av listen
  public void leggPaa(T x) {
    leggTil(x);
  }

  //ta av slutten av listen
  public T taAv() {
    return fjern(stoerrelse());
  }
}
