//import java.io.*;
public class HovedProgram {
  public static void main(String[] args) {
    System.out.println("***************LEGEMIDDEL******************");
    Legemiddel lm = new Legemiddel("Ibux", 100.0, 2.0, 0);
    PreaparatA a1 = new PreaparatA("Ibux", 100.0, 2.08, 1, 1);
    System.out.println(lm.toString());
    System.out.println("ID: " + a1.hentId() + " Narkotisk styrke: " + a1.hentNarkotiskStyrke());
    System.out.println("LegeMiddel: " + lm.hentNavn() + "nye pris er: " + lm.settNyPris(25.0));

    Legemiddel lm1 = new Legemiddel("Paracet", 49.0, 250, 2);
    PreaparatB b1 = new PreaparatB("Paracet", 49.0, 2.0, 3, 5);
    System.out.println(lm1.toString());
    System.out.println("ID: " + b1.hentId() + " Vanndanende styrke: " + b1.hentVanedannendeStyrke());
    System.out.println("LegeMiddel: " + lm1.hentNavn() + "nye pris er: " + lm1.settNyPris(150.0));

    System.out.println("***************LEGE******************");
    Lege l = new Lege("Ola Normann");
    Lege l1 = new Lege("Lisa");
    System.out.println(l.skrivResept(lm, 1, 3).toString());
    Spesialister s = new Spesialister(l1.hentNavn(), 1);
    System.out.println("KontrollID: " + s.hentKontrollID());

    System.out.println("***************BLAA-RESEPT******************");
    BlaaResepter br = new BlaaResepter(lm, s, 0, 2);
    System.out.println(br.toString());
    System.out.println("Prisen for en blaa resept er: " + br.prisAaBetale());

    System.out.println("***************HVIT-RESEPT******************");
    HviteResepter hr = new HviteResepter(lm, l, 1, 2);
    P_Resepter pr = new P_Resepter(lm, l, 2, 3);
    System.out.println(pr.toString());
    MillitaerResepter mr = new MillitaerResepter(lm, l, 3, 2);
    System.out.println(hr.prisAaBetale());
  }

  /*public static void lesInnFil(String filnavn) throws Exception {
    Scanner scan = new Scanner(new File(filnavn));
  }*/
}
