public class Legemiddel {
  protected String navn;
  protected String type;
  protected double pris;
  protected double virkestoff; //mengde

  public Legemiddel(String navn, String type, double pris, double virkestoff) {
    this.navn = navn;
    this.type = type;
    this.pris = pris;
    this.virkestoff = virkestoff;

  }

  public String hentType() {
    return type;
  }

  public String hentNavn() {
    return navn;
  }

  public double hentPris() {
    return pris;
  }

  public double hentVirkestoff() {
    return virkestoff;
  }

  public double settNyPris(double nyPris) {
    pris = nyPris;
    return nyPris;
  }

  public String toString() {
    return "Legemiddel: " + hentNavn() + " Type: " + hentType() + " Pris: " + hentPris() + " Virkestoff i mg:" + hentVirkestoff();
  }

}
