Dokumentasjonen til prekoden finner du her:
http://folk.uio.no/inf1010/v17/oblig/6/lib/doc/

NB: Filene er ikke lenger en del av pakken "krypto" slik det
står i dokumentasjonen.
