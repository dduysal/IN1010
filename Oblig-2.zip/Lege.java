public class Lege {
  protected String navnTilLege;

  public Lege(String navnTilLege) {
    this.navnTilLege = navnTilLege;
  }

  public Resepter skrivResept(Legemiddel legemiddel, int pasientID, int reit) {
    if(legemiddel instanceof PreaparatA) {
      new UlovligUtskrift(this, legemiddel);
    }
    return new HviteResepter(legemiddel, this, pasientID, reit);
  }

  public String hentNavn() {
    return navnTilLege;
  }

}
