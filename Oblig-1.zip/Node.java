public class Node {
  int minnestr;
  int antProsessor;

  public Node(int minnestr, int antProsessor) {
    this.minnestr = minnestr;
    this.antProsessor = antProsessor;
  }

  public int hentminnestr() {
    return minnestr;
  }

  public int hentAntProsessor() {
    return antProsessor;
  }
}
