public class BlaaResepter extends Resepter {
  public BlaaResepter(Legemiddel legemiddel, Lege utskrivendeLege, int pasientId, int reit) {
    super(legemiddel, utskrivendeLege, pasientId, reit);
  }

  public String farge() {
    return "blaa";
  }

  public double prisAaBetale() {
    double nyPris = (legemiddel.hentPris() * 75) / 100;
    return legemiddel.settNyPris(nyPris);
  }

}
