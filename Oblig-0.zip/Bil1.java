public class Bil1 {

  public void skrivUt() {
    System.out.println("Jeg er en bil ");
  }
}
