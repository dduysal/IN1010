public class Person {
  Bil3 bil;
  public Person(Bil3 bil) {
    this.bil = bil;
  }

  public void skrivUt() {
    bil.skrivUt();
  }
}
