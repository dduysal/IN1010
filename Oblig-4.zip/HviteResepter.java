public class HviteResepter extends Resept {
  public HviteResepter(Legemiddel legemiddel, Lege utskrivendeLege, Pasient pasient, int reit) {
    super(legemiddel, utskrivendeLege, pasient, reit);
  }

  public String farge() {
    return "hvit";
  }

  public double prisAaBetale() {
    return super.legemiddel.hentPris();
  }
}
