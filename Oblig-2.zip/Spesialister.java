//narkotiske legemidler ()
public class Spesialister extends Lege implements Godkjenningsfritak {
  int kontrollId;

  public Spesialister(String navnTilLege, int kontrollId) {
    super(navnTilLege);
    this.kontrollId = kontrollId;
  }

    public int hentKontrollID() {
      return kontrollId;
    }

    public String toString() {
      return "KontrollID-en er: " + hentKontrollID();
    }

}
