import java.io.*;
public class HovedProgram {
  public static void main(String[] args) throws Exception{
    Regnklynge lesfil = new Regnklynge("regneklynge.txt");

    System.out.println("Noder med minst 32GB: " + lesfil.noderMedNokMinne(32));
    System.out.println("Noder med minst 64GB: " + lesfil.noderMedNokMinne(64));
    System.out.println("Noder med minst 128GB: " + lesfil.noderMedNokMinne(128) + "\n");
    System.out.println("Antall prosessorer: " + lesfil.antProsessorer());
    System.out.println("Antall rack: " + lesfil.antRacks());

  } //end of main
}//end of class
