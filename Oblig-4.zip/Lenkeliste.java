import java.util.Iterator;
import java.util.NoSuchElementException;
public class Lenkeliste<T> implements Liste<T>, Iterable<T>{
  public int antall = 0;
  public Node foran;


  public int stoerrelse() {
    return antall;
  }

  public void printAlle() {
    Node temp = foran;
    while(temp != null) {
      System.out.println(temp.data);
      temp = temp.neste;
    }
  }


  //legge inn et nytt element i listen og skyve neste
  //element ett hakk lenger bak. (fifo)
  @Override
  public void leggTil(int pos, T x) {
    if (pos < 0 || pos > stoerrelse()) {
      throw new UgyldigListeIndeks(pos);
    }
    Node temp = foran;
    Node temp2 = null;

    //forste
    if(pos == 0) {
      foran = new Node(x);
      //antall++;
      if(stoerrelse() > 0) {
        foran.neste = temp;
      }
    }
    else if(pos == stoerrelse()) {
      for(int t = 0; t<pos-1; t++){
        temp = temp.neste;
      }
      temp.neste = new Node(x);
    }
    else {
      for(int t = 0; t<pos-1; t++){
        temp = temp.neste;
      }
      Node ny = new Node(x);
      ny.neste = temp.neste;
      temp.neste = ny;
    }
    antall++;
  }

  //sette inn sluttan av listen
  public void leggTil(T x) {
    if(foran == null) {
      foran = new Node(x);;
    }
    else {
        Node temp = foran;
      while(temp.neste != null) {
        temp = temp.neste;
      }
      Node ny = new Node(x);
      temp.neste = ny;

    }
    antall++;
  }

  //fjerne på gitt indeks i listen
  public T fjern(int pos) {

    if(pos < 0 || pos > stoerrelse()-1) {
      throw new UgyldigListeIndeks(pos);
    }
    //forste
    Node temp = foran;
    if(stoerrelse() == 1) {
      if(pos == 0) {
        foran = temp.neste;
        antall--;
        return temp.data;
      } else if(pos == 1) {
        foran = temp.neste;
        antall--;
        return temp.data;
      }
    }
    //midterste
    else if (temp.neste.neste != null){
      for(int i = 0; i < pos-1; i++) {
        temp = temp.neste;
      }
      Node fjern = temp.neste;
      temp.neste = temp.neste.neste;
      fjern.neste = null;
      antall--;
      return fjern.data;
    }
    //siste
    else {
      for(int i = 0; i < pos-1; i++) {
        temp = temp.neste;
      }
      Node fjern = temp;
      fjern.neste = null;
      antall--;
      return fjern.data;
    }
    antall--;
    return temp.data;
  }

  //fjerne og retunere elementet på starten av lista
  public T fjern() {
    if(stoerrelse() == 0) {
      throw new UgyldigListeIndeks(-1);
    }
      Node temp = foran;
      foran = temp.neste;
      temp.neste = null;
      antall--;
      return temp.data;
  }

  public T hent(int pos){
    if(stoerrelse() <= pos || pos < 0) {
      throw new UgyldigListeIndeks(pos);
    }
    else {
      Node temp = foran;
      for(int i = 0; i < pos; i++) {
        temp = temp.neste;
      }
      return temp.data;
    }
  }

  //sette inn elementet på en gitt posisjon og overskrive
  //det som var der fra før av.
  @Override
  public void sett(int pos, T x) {
    if(stoerrelse() <= pos||pos < 0) {
      throw new UgyldigListeIndeks(pos);
    }
    Node temp = foran;
    for(int i = 0; i < pos; i++) {
      temp = temp.neste;
    }
    temp.data = x;
    System.out.println(temp.data);
  }

  public Iterator<T> iterator() {
    return new LenkelisteIterator();
  }


//************INDRE-KLASSE***********

  private class LenkelisteIterator implements Iterator<T> {
    private Node temp;

    public LenkelisteIterator() {
      temp = foran;
    }

    @Override
    public boolean hasNext() {
      return temp.neste != null; //hvis den er sann return pos.neste
    }

    @Override
    public T next() {
      if(!hasNext()) {
        throw new NoSuchElementException();
      }
      temp = temp.neste;
      return temp.data;
    }
  } //end

  public class Node {
    Node neste;
    T data;

    public Node(T data) {
      this.data = data;
    }
  } //end

}//end of class
