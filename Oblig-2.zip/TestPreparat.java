public class TestPreparat {
  public static void main(String[] args) {
    Legemiddel ltest = new Legemiddel("Ibux", 10.0, 2.0, 0);
    System.out.println("Legemiddel navn, IBUX: " + ltest.hentNavn());
    System.out.println("LegeMiddel pris, 10kr: " + ltest.hentPris());
    System.out.println("LegeMiddel virkestoff, 2mg: " + ltest.hentVirkestoff());
    System.out.println("LegeMiddel settNyPris 15kr: " + ltest.settNyPris(15.0));

    PreaparatA a1 = new PreaparatA("Ibux", 10.0, 2.0, 0, 30);
    System.out.println("narkotiskStyrke: " + a1.hentNarkotiskStyrke());


    PreaparatB b1 = new PreaparatB("Ibux", 10.0, 2.0, 0, 50);
    System.out.println("vanndannendeStyrke: " + b1.hentVanedannendeStyrke());




  }
}
