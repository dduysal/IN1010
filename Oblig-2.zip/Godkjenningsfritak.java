public interface Godkjenningsfritak {
  public int hentKontrollID();
}
