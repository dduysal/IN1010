public class PreaparatA extends Legemiddel {
  private String narkotiskStyrke;

  public PreaparatA(String navn, String type, double pris, double virkestoff, String ns) {
    super(navn, type, pris, virkestoff);
    this.narkotiskStyrke = ns;
  }

  public String hentNarkotiskStyrke(){
    return narkotiskStyrke;
  }

  public String toString() {
    return "Legemiddel: " + super.hentNavn() + "Type: " + super.hentType() + "Pris: " + super.hentPris() + "Virkestoff i mg: " + super.hentVirkestoff() + "Narkotisk Styrke: " + hentNarkotiskStyrke();
  }

 }
