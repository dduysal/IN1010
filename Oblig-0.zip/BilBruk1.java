public class BilBruk1 {
  public static void main(String[] args) {
    Bil1 b = new Bil1();
    b.skrivUt();
  }
}
