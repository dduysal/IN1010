public class SortertLenkeliste <T extends Comparable<T> > extends Lenkeliste<T> {
  protected int antall = 0;
  public SortertLenkeliste() {
    super();
  }

  public int stoerrelseSortert() {
    return antall;
  }

  public void print() {
    Node temp = foran;
    while(temp != null) {
      System.out.println(temp.data);
      temp = temp.neste;
    }
  }

  public void leggTil(T x) {
    Node temp = foran;
    Node ny = new Node(x);
    if(stoerrelseSortert() == 0) {
      foran = ny;
      super.leggTil(foran.data);
    }
    //med et element
    /*else if(x.compareTo(foran.data) <= 0) {
      ny.neste = foran;
      foran = ny;
      super.leggTil(x);
    }*/
    else {
      while(temp.neste != null) {
        temp = temp.neste;
      }
      if(x.compareTo(temp.data) > 0) {
        super.leggTil(temp.data);
        //break;
      }
      else {
        super.leggTil(x);
        //break;
      }
    }
    antall++;
  }

  //slette det storste, altså det siste elementet
  @Override
  public T fjern() {
    if(stoerrelseSortert() == 0) {
      throw new UgyldigListeIndeks(-1);
    }
    antall--;
    return super.fjern();
  }

  @Override
  public void sett(int pos, T x) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void leggTil(int pos, T x) {
    throw new UnsupportedOperationException();
  }


}
