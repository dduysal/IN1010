public class Mintest {
  public static void main(String[] args) {
    Lenkeliste<Integer> liste = new Lenkeliste<Integer>();
    System.out.println("for sett inn stoerrelse: " + liste.stoerrelse());

    liste.leggTil(0, 4);
    //liste.printAlle();
    liste.leggTil(1, 5);
    //liste.printAlle();
    liste.leggTil(2, 6);
    liste.leggTil(3, 8);
    liste.leggTil(9);

    System.out.println("Print alle lagt inn");
    liste.printAlle();

    System.out.println("FJERN MED POS");
    System.out.println(liste.fjern(1));
    System.out.println(liste.fjern(2));


    System.out.println("FJERN UTEN POS");
    System.out.println(liste.fjern());

    System.out.println("Print alle etter fjern");
    liste.printAlle();

    System.out.println("hent: " + liste.hent(1));
    System.out.println("sett: ");
    liste.sett(0, 7);

    System.out.println("Print alle etter sett");
    liste.printAlle();


    System.out.println("stoerrelse etter alle funksjonene: " + liste.stoerrelse());




  }
}
