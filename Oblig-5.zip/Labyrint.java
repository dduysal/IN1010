import java.io.*;
import java.util.*;

public class Labyrint {
  private  Rute[][] lab; //[antR] [antK]
  private int antR;
  private int antK;

  Lenkeliste<String> utvei = new Lenkeliste<String>();

  private Labyrint(int r, int k, Rute[][] lab) {
    this.antR = r;
    this.antK = k;
    this.lab = lab;
  }

  //den ruten er den på kanten/enden
  public boolean aapning(int x, int y, int maxX, int maxY) {
    Rute rute = hentPos(x,y);
    if(x == 0 || y == 0 || maxY == y || maxX == x && rute instanceof Aapning) {
      return true;
    }
    return false;
  }

  public static Labyrint lesFraFil(File fil) throws FileNotFoundException {
    Scanner scan = new Scanner(fil);
    int x = 0;

    String []ant = scan.nextLine().split(" ");
    int r = Integer.parseInt(ant[0]);
    int k = Integer.parseInt(ant[1]);
    Rute [][] l = new Rute[r][k];

    Labyrint labyrint = new Labyrint(r , k, l);
    System.out.println("Antall rader: " + r + " Antall kolonner: " + k);


    while(scan.hasNextLine()) {
      String linje = scan.nextLine();
      char[] tegn = linje.toCharArray();

      for(int y = 0; y < tegn.length; y++) {
        if(tegn[y] == '#') {
          Rute sr = new SortRute(x, y, labyrint);
          labyrint.lab[x][y] = sr;
          //System.out.println(l[x][y]);
        }
        else if(labyrint.aapning(x, y, r, k) == true && tegn[y] == '.') {
            Rute aa = new Aapning(x, y, labyrint);
            labyrint.lab[x][y] = aa;
            //System.out.println("Apning!!!!!" + l[x][y]);
        }
        else if (tegn[y] == '.') {
          Rute hr = new HvitRute(x, y, labyrint);
          labyrint.lab[x][y] = hr;
          //System.out.println(l[x][y]);
        }
        else {
          System.out.println("feil");
        }
      }
        x++;
    }

    /*for(int i = 0; i< l.length; i++) {
      for(int p = 0; p < l[i].length; p++) {
        labyrint.lab[i][p].settNaboer();
      }
    }*/

    return labyrint;
  }


  @Override
  public String toString() {
    String l = "";
    for(int rad = 0; rad < antR; rad++) {
      for(int kolonne = 0; kolonne < antK; kolonne++) {
        l += lab[rad][kolonne].tilTegn();
        if(kolonne == antK-1) {
          l += "\n";
        }
      }
    }
    return l;
  }

  public Labyrint hentLabyrint() {
    return this;
  }

  public Rute hentPos(int posX, int posY) {
  //  System.out.println( "(" + (posX) + ", " + (posY) + ")" + "-->"  );
    return lab[posX][posY];
  }

  public Lenkeliste<String> finnUtveiFra(int kol, int rad) {
    hentPos(rad,  kol).finnUtvei();
    return utvei;
  }
  public void settUtveier(String utveier){
    utvei.leggTil(utveier);
  }

  public void printListe() {
    utvei.printAlle();
  }

  public int hentR() {
    return antR;
  }

  public int hentK() {
    return antK;
  }


}
