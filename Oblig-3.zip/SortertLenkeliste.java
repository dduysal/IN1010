public class SortertLenkeliste <T extends Comparable<T> > extends Lenkeliste<T> {

  public SortertLenkeliste() {
    super();
  }

  @Override
  public void leggTil(T x) {
    Node temp = foran;
    Node ny = new Node(x);

    //hvis listen er tom
    if(stoerrelse() == 0) {
      foran = ny;

    }
    //hvis det er en node fra før i liste
    if(stoerrelse() >= 1) {
      System.out.println("heii");
      if(x.compareTo(foran.data) >= 0) {
        super.leggTil(x);
      }
      else {
        super.leggTil(foran.data);
      }
    }
  }

  //slette det storste, altså det siste elementet
  @Override
  public T fjern() {
    if(stoerrelse() == 0 || stoerrelse() < 0) {
      throw new UgyldigListeIndeks(-1);
    }
    return super.fjern(stoerrelse());
  }

  @Override
  public void sett(int pos, T x) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void leggTil(int pos, T x) {
    throw new UnsupportedOperationException();
  }


}
