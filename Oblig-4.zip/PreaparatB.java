public class PreaparatB extends Legemiddel{
  private String vanndannendeStyrke;

  public PreaparatB(String navn, String type, double pris, double virkestoff, String vs) {
    super(navn, type, pris, virkestoff);
    this.vanndannendeStyrke = vs;
  }

  public String hentVanedannendeStyrke(){
    return vanndannendeStyrke;
  }

  public String toString() {
    return "Legemiddel: " + super.hentNavn() + "Type: " + super.hentType() + "Pris: " + super.hentPris() + "Virkestoff i mg: " + super.hentVirkestoff() + "Vanndannende Styrke: " + hentVanedannendeStyrke();
  }

}
