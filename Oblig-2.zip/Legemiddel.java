public class Legemiddel {
  protected String navn;
  protected double pris;
  protected double virkestoff; //mengde
  protected int Id;

  public Legemiddel(String navn, double pris, double virkestoff, int Id) {
    this.navn = navn;
    this.pris = pris;
    this.virkestoff = virkestoff;
    this.Id = Id;
  }

  public int hentId() {
    return Id;
  }

  public String hentNavn() {
    return navn;
  }

  public double hentPris() {
    return pris;
  }

  public double hentVirkestoff() {
    return virkestoff;
  }

  public double settNyPris(double nyPris) {
    pris = nyPris;
    return nyPris;
  }

  public String toString() {
    return "Legemiddel: " + hentNavn() + " ID: " + hentId() + " Pris: " + hentPris() + " Virkestoff i mg: " + hentVirkestoff();
  }

}
