public class PreaparatB extends Legemiddel{
  private int vanndannendeStyrke;

  public PreaparatB(String navn, double pris, double virkestoff, int Id, int vs) {
    super(navn, pris, virkestoff, Id);
    this.vanndannendeStyrke = vs;
  }

  public int hentVanedannendeStyrke(){
    return vanndannendeStyrke;
  }

}
