import java.util.*;
public class Lenkeliste<T> implements Liste<T> {
  public int antall = 0;
  public Node foran;


  public int stoerrelse() {
    return antall;
  }

  public void printAlle() {
    Node temp = foran;
    while(temp != null) {
      System.out.println(temp.data);
      temp = temp.neste;
    }
  }

  //legge inn et nytt element i listen og skyve neste
  //element ett hakk lenger bak. (fifo)
  @Override
  public void leggTil(int pos, T x) {
    if (pos < 0 || pos > stoerrelse()) {
      throw new UgyldigListeIndeks(pos);
    }
    Node temp = foran;
    Node temp2 = null;
    Node ny = new Node(x);
    //forste
    if(pos == 0) {
      foran = ny;
      antall++;
      if(stoerrelse() > 0) {
        foran.neste = temp;
      }
    }
    //midterste
    else if(pos != stoerrelse()) {
      for(int i = 0; i < pos; i++) {
        temp = temp.neste;
      }
      temp2 = temp.neste;
      temp.neste = ny;
      ny.neste = temp2;
      antall++;
    }
    //siste
    else {
      for(int i = 0; i < pos-1; i++) {
        temp = temp.neste;
      }
      temp.neste = ny;
      antall++;
    }
  }

  //sette inn sluttan av listen
  public void leggTil(T x) {
    Node ny = new Node(x);
    Node temp = foran;
    if(foran == null) {
      foran = ny;
      antall++;
    }
    else {
      while(temp.neste != null) {
        temp = temp.neste;
      }
      temp.neste = ny;
      antall++;
    }
  }

  //fjerne på gitt indeks i listen
  @Override
  public T fjern(int pos) {
    if(stoerrelse() == 0 || pos < 0 || stoerrelse() < pos || stoerrelse() < 0) {
      throw new UgyldigListeIndeks(pos);
    }
    Node temp = foran;
    //forste
    if(foran != null) {
      foran = foran.neste;
      antall--;
      return temp.data;
    }
    //midterste
    else if (temp.neste != null){
      for(int i = 0; i < pos-1; i++) {
        temp = temp.neste;
      }
      temp.neste = temp.neste.neste;
      antall--;
      return temp.data;
    }
    //siste
    else {
      Node temp2 = temp.neste.neste;
      temp.neste = temp2;
      antall--;
      return temp.data;
    }
  }


  //fjerne og retunere elementet på starten av lista
  public T fjern() {
    if(stoerrelse() == 0) {
      throw new UgyldigListeIndeks(-1);
    }
    //else {
      Node temp = foran;
      foran = temp.neste;
      temp.neste = null;
      antall--;
      return temp.data;
    //}
  }

  public T hent(int pos){
    if(stoerrelse() <= pos || pos < 0 ) {
      throw new UgyldigListeIndeks(pos);
    }
    else {
      Node temp = foran;
      for(int i = 0; i < pos; i++) {
        temp = temp.neste;
      }
      return temp.data;
    }
  }

  //sette inn elementet på en gitt posisjon og overskrive
  //det som var der fra før av.
  @Override
  public void sett(int pos, T x) {
    if(stoerrelse() <= pos||pos < 0) {
      throw new UgyldigListeIndeks(pos);
    }
    Node temp = foran;
    for(int i = 0; i < pos; i++) {
      temp = temp.neste;
    }
    temp.data = x;
    System.out.println(temp.data);
  }


//************INDRE-KLASSE***********
  public class Node {
    Node neste;
    T data;

    public Node(T data) {
      this.data = data;
    }
  }
}//end of class
