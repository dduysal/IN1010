public class Kryptografer extends Thread {
  Dekryptert_Monitor dmonitor;
  Kryptert_Monitor kmonitor;
  String s;

  public Kryptografer(Dekryptert_Monitor dmonitor, Kryptert_Monitor kmonitor) {
    this.dmonitor = dmonitor;
    this.kmonitor = kmonitor;
  }

  public void run() {
    Melding melding = kmonitor.hentFraKryptertMonitor(); //mottat mld fra kmonitor
    while(melding.hentMelding() != null) {
      String s = Kryptografi.dekrypter(melding.hentMelding()); //dekrypterer
      Melding m = new Melding(melding.hentSekvensnr(), melding.hentId(), s);
      dmonitor.settInnDekrypteMonitor(m); //sender inn dekryptert melding til monitoren
    }
  }
}
