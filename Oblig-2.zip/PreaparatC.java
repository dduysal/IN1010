public class PreaparatC extends Legemiddel {

  public PreaparatC(String navn, double pris, double virkestoff, int Id) {
    super(navn, pris, virkestoff, Id);
  }
}
