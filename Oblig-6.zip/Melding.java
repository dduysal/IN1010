//meldinger i monitoren er krypterte og må dekrypteres av kryptografene
public class Melding {
  private int sekvensnummer;
  private int id;
  private String melding;

  public Melding(int sekvensnummer, int id, String melding) {
    this.sekvensnummer = sekvensnummer;
    this.id = id;
    this.melding = melding;
  }

  public int hentSekvensnr() {
    return sekvensnummer;
  }

  public int hentId() {
    return id;
  }

  public String hentMelding() {
    return melding;
  }

  public String toString() {
    return hentMelding();
  }
}
