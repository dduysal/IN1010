import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;
import java.util.*;

public class Dekryptert_Monitor {
  ArrayList<String> forste = new ArrayList<String>();
  ArrayList<String> andre = new ArrayList<String>();
  ArrayList<String> tredje = new ArrayList<String>();

  ArrayList<Melding> alleDekrypteMeldinger = new ArrayList<Melding>();
  Iterator<Melding> iterator = alleDekrypteMeldinger.iterator();

  Lock laas = new ReentrantLock();
  Condition tilgang = laas.newCondition();

  public void settInnDekrypteMonitor(Melding melding) {
    laas.lock();
    try {
      alleDekrypteMeldinger.add(melding);
      tilgang.signalAll();
    }
       finally {
      laas.unlock();
    }
  }

  public Melding hentFraDekrypteMonitor() {
    Melding m = null;
    laas.lock();
    try {
      while(alleDekrypteMeldinger.isEmpty()) {
        tilgang.await();
      }
      m = alleDekrypteMeldinger.remove(0);
    } catch (InterruptedException n) {}
      finally {
        laas.unlock();
    }
    return m;
  }

  public void sjekk() {
    for(Melding m : alleDekrypteMeldinger) {
      System.out.println(m.toString());
    }
  }


  public Melding SorterMeldinger() {
    Melding melding = hentFraDekrypteMonitor();
    //System.out.println(melding);
    for(Iterator<Melding> iterator = alleDekrypteMeldinger.iterator(); iterator.hasNext();) {
      if(melding.hentId() == 1) {
        forste.add(melding.hentMelding());
        Collections.sort(forste);
      }
      else if(melding.hentId() == 2) {
        andre.add(melding.hentMelding());
        Collections.sort(andre);
      }
      else if(melding.hentId() == 3) {
        tredje.add(melding.hentMelding());
        Collections.sort(tredje);
      }
    }
    return melding;
  }




}
