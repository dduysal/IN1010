public abstract class Resepter {
  protected Legemiddel legemiddel;
  protected Lege utskrivendeLege;
  protected int pasientId;
  protected int reit;

  public Resepter(Legemiddel legemiddel, Lege utskrivendeLege, int pasientID, int reit) {
    this.pasientId = pasientId;
    this.legemiddel = legemiddel;
    this.utskrivendeLege = utskrivendeLege;
    this.reit = reit;
  }

  public int hentId() {
    return legemiddel.hentId();
  }

  public double hentPrisFraLegeMiddel() {
    return prisAaBetale();
  }

  public Legemiddel hentLegeMiddel() {
    return legemiddel;
  }

  public Lege hentLege() {
    return utskrivendeLege;
  }

  public int hentPasientId() {
    return pasientId;
  }

  public int hentReit() {
    return reit;
  }

  public boolean bruk() {
    if(reit <= 0) {
      return false;
    }
    return true;
  }

  public String toString() {
return "Legemiddel: " + this.legemiddel.hentNavn() + ", UtskrivendeLege: " + this.utskrivendeLege.hentNavn() + ", pasientID: " + hentPasientId() + ", Reit: " + hentReit();
  }

  //for aa kunne implemntere en abstract metode kan man lage en subklasse og lage akkurat den samme metoden
  abstract public String farge();

  abstract public double prisAaBetale();

}
