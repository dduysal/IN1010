public class P_Resepter extends HviteResepter {
  public P_Resepter(Legemiddel legemiddel, Lege utskrivendeLege, Pasient pasient, int reit) {
    super(legemiddel, utskrivendeLege, pasient, reit);
    reit = 3;

  }

  @Override
  public double prisAaBetale() {
    double prisMRabatt = legemiddel.hentPris() - 116;
    if(prisMRabatt > 0) {
      return legemiddel.settNyPris(prisMRabatt);
    }
    return 0.0; //retunerern 0 hvis prisMRabatt er mindre enn 0
  }
}
