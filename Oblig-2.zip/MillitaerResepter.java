public class MillitaerResepter extends HviteResepter {
  public MillitaerResepter(Legemiddel legemiddel, Lege utskrivendeLege, int pasientId, int reit) {
    super(legemiddel, utskrivendeLege, pasientId, reit);
  }

  public double prisAaBetaleMillitaerResepter() {
    //gir 100% rabatt paa Legemiddel
    return legemiddel.settNyPris(0.0);
  }


}
