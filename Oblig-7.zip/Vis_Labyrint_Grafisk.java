import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import javafx.application.Application;
import javafx.scene.layout.Pane;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Rectangle;
import java.io.FileNotFoundException;
import javafx.scene.paint.Color;
import javafx.scene.input.MouseEvent;

public class Vis_Labyrint_Grafisk extends Application {
  GridPane rutenett;
  BorderPane borderpane;
  TextField fil;
  FileChooser filvelger;
  File valgtFil = new File("");
  Button velgFil, lastOpp;
  Rectangle[][] rute;
  boolean[][] ruteLosninger;
  Lenkeliste <String> utveier;
  Rectangle sort, hvit;
  int antL = 0;

  public void start(Stage stage) {
    //hele oppsettet
    borderpane = new BorderPane();
    stage.setTitle("Labyrint");
    stage.setScene(new Scene(borderpane, 800, 800));
    stage.show();
    borderpane.setTop(innlesningAvFil(stage));


    lastOpp.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent e){
        try {
          borderpane.setCenter(ruteNett());
          borderpane.setBottom(bunnlinjen());
        } catch(FileNotFoundException f) {};
        stage.sizeToScene();
      }
    });
  }

  //topplinjen ->fil innlesning
  public HBox innlesningAvFil(Stage stage) {
    //knapper
    fil = new TextField();
    velgFil = new Button("Velg fil");
    lastOpp = new Button("Last opp");

    velgFil.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent ae){
        filvelger = new FileChooser();
        filvelger.setTitle("Velg Labyrint-fil");
        ExtensionFilter filter = new ExtensionFilter("tekstfiler", "*.in");
        valgtFil = filvelger.showOpenDialog(stage);
        System.out.println(valgtFil);
        if (valgtFil != null) {
          fil.setText(valgtFil.getPath());
        }
      }
    });
    return new HBox(10.0, fil ,velgFil, lastOpp);
  }

  ////midterste felt ->fremvisning  av ruternettet
  public GridPane ruteNett() throws FileNotFoundException {
    rutenett = new GridPane();
    try {
      Labyrint lab = Labyrint.lesFraFil(valgtFil);
      rute = new Rectangle[lab.hentR()][lab.hentK()];

      for(int x = 0; x < rute.length; x++) {
        for(int y = 0; y < rute[x].length; y++) {
          rute[x][y] = new Rectangle();
          rutenett.add(rute[x][y], x, y);
          Rute r = lab.hentPos(x, y);

          if(r.tilTegn().equals("#")) {
            sort = new Rectangle(20, 20);
            sort.setFill(Color.BLACK);
            sort.setStroke(Color.CORAL);
            rutenett.add(sort, y, x);
          }
          if(r.tilTegn().equals(".")) {
            hvit = new Rectangle(20, 20);
            hvit.setFill(Color.WHITE);
            hvit.setStroke(Color.CORAL);
            rutenett.add(hvit, y, x);
            final int finalK = y;
            final int finalR = x;

            hvit.setOnMouseClicked(new EventHandler<MouseEvent>() {
              public void handle(MouseEvent hvitEvent) {
                utveier = lab.finnUtveiFra(finalK, finalR);
                //hvit.setFill(Color.GREEN); //den ruten bruker taster blir GREEN, losninge blir BLÅ

                if(utveier.stoerrelse() > 0) {
                  String losningUtvei = utveier.fjern();
                  boolean [][] losning = losningStringTilTabell(losningUtvei, lab.hentR(), lab.hentK());
                  System.out.println("----------------------");


                  for(int r = 0; r < losning.length; r++) {
                    for(int k = 0; k < losning[r].length; k++) {
                      if(losning[r][k] == true) {
                        Rectangle l = new Rectangle(20, 20);
                        l.setFill(Color.BLUE);
                        rutenett.add(l, r, k);
                        antL++;
                      }
                    }
                  }
                }
              }
            });
          }
        }
      }

    } catch(FileNotFoundException f) {
      System.out.println("Fant ikke filen");
    };

    return rutenett;
  }

  /**
 * Konverterer losning-String fra oblig 5 til en boolean[][]-representasjon
 * av losningstien.
 * @param losningString String-representasjon av utveien
 * @param bredde        bredde til labyrinten
 * @param hoyde         hoyde til labyrinten
 * @return              2D-representasjon av rutene der true indikerer at
 *                      ruten er en del av utveien.
 */
static boolean[][] losningStringTilTabell(String losningString, int bredde, int hoyde) {
    boolean[][] losning = new boolean[hoyde][bredde];
    java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\(([0-9]+),([0-9]+)\\)");
    java.util.regex.Matcher m = p.matcher(losningString.replaceAll("\\s",""));
    while (m.find()) {
        int x = Integer.parseInt(m.group(1));
        int y = Integer.parseInt(m.group(2));
        losning[y][x] = true;
    }
    return losning;
}

  //bunnlinjen ->printer utveier
  public HBox bunnlinjen() {
    Label totale = new Label("Totale losninger:");
    TextField totalinput = new TextField();
    String antLosninger = Integer.toString(antL);
    totalinput.setText(antLosninger);
    return new HBox(200.0, totale, totalinput);
  }

  public static void main(String[] args) {
    Application.launch(); //starter det hele
  }
}
