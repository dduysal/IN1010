import java.io.*;
import java.util.*;


//skal skrive melding til en fil, en fil for hver kanal
public class Operasjonsleder extends Thread {
  Dekryptert_Monitor monitor;
  Operasjonssentral sentral;

  public Operasjonsleder(Dekryptert_Monitor monitor, Operasjonssentral sentral) {
    this.monitor = monitor;
    this.sentral = sentral;
  }

  //hente meldinger fra monitoren
  public void run() {
    while(monitor.hentFraDekrypteMonitor() != null) {
      Melding melding = monitor.hentFraDekrypteMonitor();
      printWrite(melding);
    }
  }

  /*skriver en melding til fil, men en fil for hver kanal.
  Hver melding skal være adskilt av to linjeskrift.
  Må komme i riktig rekkefølge*/
  public void printWrite(Melding m) { //en fil skal være fylt med en kanal med meldinger med en fil for hver kanal
    PrintWriter skriveTilFil = null;
      try {
        //for(int i = 0; i < 1; i++) {
          /*String filnavn = "utfil.txt";
          skriveTilFil = new PrintWriter(filnavn, "utf-8");
          skriveTilFil.append(m.toString());*/
          System.out.println(m.toString());

        //}
        //skriveTilFil.close();
      } catch (Exception f) {};
  }


} //end of class
