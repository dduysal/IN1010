public class Lege implements Comparable<Lege> {
  protected String navnTilLege;
  protected Resept r;
  Lenkeliste<Resept> utskrevedeResepter = new Lenkeliste<Resept>();

  public Lege(String navnTilLege) {
    this.navnTilLege = navnTilLege;
  }

  public String hentNavn() {
    return navnTilLege;
  }

  @Override
  public int compareTo(Lege l) {
    if(this.navnTilLege.compareTo(l.navnTilLege) <= 0) {
      return 0;
    }
    else if(this.navnTilLege.compareTo(l.navnTilLege) > -1){
      return -1;
    }
    else {
      System.out.println("blir ikke lagt inn!");
      return 2;
    }
  }

  public String toString() {
    return "Lege: " + hentNavn() + ", ";
  }

  public Resept skrivResept(Legemiddel legemiddel, Lege lege, Pasient pasient, int reit) {
    if(legemiddel instanceof PreaparatA) {
      new UlovligUtskrift(this, legemiddel);
    }
    HviteResepter hr = new HviteResepter(legemiddel, lege, pasient, reit);
    return hr;
  }

  public void leggTilResept(Resept r) {
    utskrevedeResepter.leggTil(r);
  }

  public Lenkeliste<Resept> hentListe() {
    return utskrevedeResepter;
  }



  /*public HviteResepter skrivHvitResept(Legemiddel legemiddel, Pasient pasient, int reit){
    if(legemiddel instanceof PreaparatA) {
      new UlovligUtskrift(this, legemiddel);
    }
    HviteResepter hr = new HviteResepter(legemiddel, this, pasient, reit);
    utskrevedeResepter.leggTil(hr);
    return hr;
  }

  public BlaaResepter skrivBlaaResepter(Legemiddel legemiddel, Pasient pasient, int reit){
    if(legemiddel instanceof PreaparatA) {
      new UlovligUtskrift(this, legemiddel);
    }
    BlaaResepter br = new BlaaResepter(legemiddel, this, pasient, reit);
    utskrevedeResepter.leggTil(br);
    return br;
  }

  public P_Resepter skrivP_Resepter(Legemiddel legemiddel, Pasient pasient, int reit){
    if(legemiddel instanceof PreaparatA) {
      new UlovligUtskrift(this, legemiddel);
    }
    P_Resepter pr = new P_Resepter(legemiddel, this, pasient, reit);
    utskrevedeResepter.leggTil(pr);
    return pr;
  }

  public MillitaerResepter skrivMillitaerResepter(Legemiddel legemiddel, Pasient pasient, int reit){
    if(legemiddel instanceof PreaparatA) {
      new UlovligUtskrift(this, legemiddel);
    }
    MillitaerResepter mr = new MillitaerResepter(legemiddel, this, pasient, reit);
    utskrevedeResepter.leggTil(mr);
    return mr;
  }*/

} //end
