public class Telegrafi extends Thread {
  Kanal kanal;
  Kryptert_Monitor monitor;
  int teller = 0;
  String s;

  public Telegrafi (Kanal kanal, Kryptert_Monitor monitor) {
    this.kanal = kanal;
    this.monitor = monitor;
  }

  public void run() {
    while(kanal.lytt() != null) {
      Melding mld = new Melding(teller, kanal.hentId(), s);
      monitor.settInnKryptertMonitor(mld);
      s = kanal.lytt();
      teller++;
    }
  }
} // end of class
