import java.util.*;
import java.io.*;

public class Legesystem {
  // Opprett lister som lagrer objektene i legesystemet
  private static Lenkeliste<Resept> utskrevendeResept = new Stabel<Resept>();
  private static SortertLenkeliste<Lege> legeliste = new SortertLenkeliste<Lege>();
  private static Lenkeliste<Pasient> pasientliste = new Lenkeliste<Pasient>();
  private static Lenkeliste<Legemiddel> lmliste = new Lenkeliste<Legemiddel>();
  private static int tellerLegemiddel = -1;
  private static int pid = -1;
  static int input = 0;

  public static void main(String[] args){
    File fil = new File("vedlegg2.txt");
    lesFraFil(fil);
    kommandolokke();
  }

  public static void kommandolokke() {
    System.out.println("\n*********** Legesystem ***********");
    while(input < 4) {
      System.out.println("Tast \t - 0 - for å printe ut alle lister ");
      System.out.println("Tast \t - 1 - for å legge til");
      System.out.println("Tast \t - 2 - for finne pasientens resepter");
      System.out.println("Tast \t - 3 - for å hente ut statistikk");
      System.out.println("Tast \t - 4 - for å avsluttelegesystemet");
      Scanner scan = new Scanner(System.in);
      input = scan.nextInt();

        if (input == 0) {
          printAlleLister();
        }

        if (input == 1) {
          leggeTilLister();
        }

        if (input == 2) {
          brukerInput();
        }

        if (input == 3) {
        statistikk();
        }
    }
  }

  public static void printAlleLister() {
    System.out.println("******PASIENTER*******");
    for(Pasient p : pasientliste) {
      System.out.println(p.toString());
      System.out.println("\t Pasientens resepter:");
      for(Resept r : p.hentListe()) {
        System.out.println(r.toString() + "\n\n");
      }
    }

    System.out.println("******LEGEMIDDLER*******");
    for (Legemiddel l : lmliste) {
      System.out.println(l.toString() + "\n");
    }

    System.out.println("******LEGER*******");
    try {
      for(Lege l : legeliste) {
        System.out.println(l.toString());
        System.out.println("\t Legens reseptliste:");
        /*for(Resept r : l.hentListe()) {
          System.out.println("\t " + r.toString() + "\n\n");
        }*/
      }
    } catch(NullPointerException n) {};

  }

  public static void leggeTilLister() {
    System.out.println("*****LEGG TIL I SYSTEMET****");
    System.out.println("Tast inn \t - 0 - for å legge til en pasient");
    System.out.println("Tast inn \t - 1 - for å legge til et legemiddel");
    System.out.println("Tast inn \t - 2 - for å legge til en lege");
    System.out.println("Tast inn \t - 3 - for å legge til er resept");
    Scanner scan = new Scanner(System.in);
    int input = scan.nextInt();

    if(input == 0) {
      String navn = scan.nextLine();
      System.out.println("Navn:");
      navn = scan.nextLine();

      System.out.println("Fodselsnummer:");
      String fnr = scan.nextLine();
      pid++;
      leggTilPasient(navn, fnr, pid);
    }

    if(input == 1) {
      String navn = scan.nextLine();
      System.out.println("Navn pa legemiddel:");
      navn = scan.nextLine();

      System.out.println("Skriv inn type");
      String type = scan.nextLine();
      double pris = 0;
      double virkestoff = 0;
        if(type.equals("a")) {
          try {

            System.out.println("Skriv inn pris:");
            pris = scan.nextDouble();

            System.out.println("Skriv inn virkestoff");
            virkestoff = scan.nextDouble();

          }
          catch (NumberFormatException|InputMismatchException e) {
            System.out.println("Du må skrive inn et tall, prøv på nytt");
            System.out.println("Skriv inn pris:");
            pris = scan.nextDouble();

            System.out.println("Skriv inn virkestoff");
            virkestoff = scan.nextDouble();
          }

          System.out.println("Skriv inn narkotisk styrke");
          String ns = scan.nextLine();
          ns = scan.nextLine();

          leggTilA(navn, type, pris, virkestoff, ns);
        }
        else if(type.equals("b")) {
          double prisB = 0;
          double virkestoffB = 0;

          try {
            System.out.println("Skriv inn pris:");
            prisB = scan.nextDouble();

            System.out.println("Skriv inn virkestoff");
            virkestoffB = scan.nextDouble();
          }
          catch (NumberFormatException|InputMismatchException e) {
            System.out.println("Du må skrive inn et tall, prøv på nytt");
            System.out.println("Skriv inn pris:");
            prisB = scan.nextDouble();

            System.out.println("Skriv inn virkestoff");
            virkestoffB = scan.nextDouble();
          }
          String vs = scan.nextLine();
          System.out.println("Skriv inn vanedannende styrke");
          vs = scan.nextLine();
          leggTilB(navn, type, prisB, virkestoffB, vs);
        }
        else {
          double prisC = 0;
          double virkestoffC = 0;
          try {
            System.out.println("Skriv inn pris:");
            prisC = scan.nextDouble();

            System.out.println("Skriv inn virkestoff");
            virkestoffC = scan.nextDouble();
          }
          catch (NumberFormatException|InputMismatchException e) {
            System.out.println("Du må skrive inn et tall, prøv på nytt");
            System.out.println("Skriv inn pris:");
            prisC = scan.nextDouble();

            System.out.println("Skriv inn virkestoff");
            virkestoffC = scan.nextDouble();
          }
          leggTilC(navn, type, prisC, virkestoffC);
        }
        lmliste.printAlle();
    }

    if(input == 2) {
      System.out.println("Lege navn:");
      String legenavn = scan.nextLine();
      legenavn = scan.nextLine();

      System.out.println("Kontroll ID");
      int kid = scan.nextInt();

      leggTilLege(legenavn);

        if(kid > 0) {
        leggTilSpesialist(legenavn, kid);
        }

    }

    if(input == 3) {
      Pasient pasient = null;
      Legemiddel legemiddel = null;
      Lege lege = null;

      String navn = scan.nextLine();
      System.out.println("Pasientens navn:");

      navn = scan.nextLine();
      for(Pasient p : pasientliste) {
        if(p.hentNavn().equals(navn)) {
          pasient = p;
        }
      }

      System.out.println("Hvilket legemiddel ønsker du å lage resept til?");
      navn = scan.nextLine();
      for(Legemiddel lm : lmliste) {
        if(lm.hentNavn().equals(navn)) {
          legemiddel = lm;
        }
      }

      System.out.println("Leges navn:");
      navn = scan.nextLine();
      for(Lege l : legeliste) {
        if(l.hentNavn().equals(navn)) {
          lege = l;
        }
      }

      if (pasient == null) System.out.println("Pasienten du la inn finnes ikke i systemet");
      if (legemiddel == null) System.out.println("Legemiddelet du la inn finnes ikke i systemet");
      if (lege == null) System.out.println("Legen du la inn finnes ikke i systemet");
      int reit = 0;

      try {
        System.out.println("Skriv inn reit: ");
        reit = scan.nextInt();
      } catch(InputMismatchException ime) {
        System.out.println("Du skrev inn feil input for reit");
      };

        Resept r = lege.skrivResept(legemiddel, lege, pasient, reit);
        pasient.leggTilResept(r);
        lege.leggTilResept(r);
        utskrevendeResept.leggTil(r);
    }
  }

  public static void brukerInput() {
    int tellerLM = 0;
    int tellerP = 0;
    Pasient pasient = null;
    Resept resept = null;
    Scanner scan = new Scanner(System.in);
    System.out.println("Hvilken pasient vil du se resept for?");

    for(Pasient p : pasientliste) {
      pasient = p;
      System.out.println(tellerP + ": " + pasient.toString());
      tellerP++;
    }

    int valgtPasient = scan.nextInt();

    if(valgtPasient != tellerP) {
      System.out.println("Valgt Pasient: " + pasient.toString() + "\n");
      System.out.println("Hvilken resept vil du bruke?");
      for(Resept r : pasient.hentListe()) {
        resept = r;
        System.out.println(tellerLM + ": " + r.toString() + "\n");
        tellerLM++;
      }
    }

    int gjenvaerendeReit = resept.hentReit() -1;
    System.out.println("Brukte resept paa: " + resept.toString() + " Antall gjenvaerende reit: " + gjenvaerendeReit);
  }

  public static void statistikk() {

    int vann = 0;
    int nar = 0;
    for(Resept r : utskrevendeResept) {
      if(r.hentType().equals("b")) {
        vann++;
      }
      if(r.hentType().equals("a")) {
        nar++;
      }
    }

    System.out.println("ANTALL UTSKREVNE NARKOTISKE LEGEMIDLER " + nar);
    System.out.println("ANTALL UTSKREVNE VANNDANNENDE LEGEMIDLER " + vann + "\n");

    String navnL = "";
    int antL = 0;
    for(Lege l : legeliste) {
      navnL = l.hentNavn();
      for(Resept r : utskrevendeResept) {
        if(r.hentType().equals("a") && l.hentNavn().equals(r.hentLege().hentNavn())) {
          antL++;
        }
      }
    }
    System.out.println("LEGE: " + navnL + " SKREVET UT ANTALL NARKOTISKE LEGEMIDLER " + antL);

    String navnP = "";
    int antP = 0;
    for(Pasient p : pasientliste) {
      navnP = p.hentNavn();
      for(Resept r : utskrevendeResept) {
        if(r.hentType().equals("a") && p.hentNavn().equals(r.hentPasient().hentNavn())) {
          antP++;
        }
      }
    }
    System.out.println("PASIENT: " + navnP + " MED ANTALL NARKOTISKE LEGEMIDLER " + antP);

  }

  private static void lesFraFil(File fil){
    Scanner scanner = null;
    try{
      scanner = new Scanner(fil);
    }catch(FileNotFoundException e){
      System.out.println("Fant ikke filen, starter opp som et tomt Legesystem");
      return;
    }

    String innlest = scanner.nextLine();

    while(scanner.hasNextLine()) {
      String[] info = innlest.split(" ");
      // Legger til alle pasientene i filen
      if(info[1].compareTo("Pasienter") == 0){

        while(scanner.hasNextLine()) {
          innlest = scanner.nextLine();
          String[] pasientInfo = innlest.split(",");
          String navnPasient = pasientInfo[0];
          String fnr = pasientInfo[1];
          pid++;
          if(innlest.charAt(0) == '#'){
            break;
          }
          leggTilPasient(navnPasient, fnr, pid);
        }
      }
      //Legger inn Legemidlene
      else if(info[1].compareTo("Legemidler") == 0){
        while(scanner.hasNextLine()){
          innlest = scanner.nextLine();

          if(innlest.charAt(0) == '#'){
            break;
          }
          String[] legemiddel = innlest.split(", ");

          if(legemiddel[1].compareTo("a") == 0){
            String[] lmInfo = innlest.split(", ");
            String navn = lmInfo[0];
            String type = lmInfo[1];
            double pris = Double.parseDouble(lmInfo[2]);
            double virkestoff = Double.parseDouble(lmInfo[3]);
            String styrke = lmInfo[4];
            leggTilA(navn, type, pris, virkestoff, styrke);
            tellerLegemiddel++;
          }
          else if(legemiddel[1].compareTo("b") == 0){
            String[] lmBInfo = innlest.split(",");
            String navn = lmBInfo[0];
            String type = lmBInfo[1];
            double pris = Double.parseDouble(lmBInfo[2]);
            double virkestoff = Double.parseDouble(lmBInfo[3]);
            String styrke = lmBInfo[4];
            leggTilB(navn, type, pris, virkestoff, styrke);
            tellerLegemiddel++;
          }
          else if (legemiddel[1].compareTo("c") == 0){
            String[] lmCInfo = innlest.split(",");
            String navn = lmCInfo[0];
            String type = lmCInfo[1];
            double pris = Double.parseDouble(lmCInfo[2]);
            double virkestoff = Double.parseDouble(lmCInfo[3]);
            leggTilC(navn, type, pris, virkestoff);
            tellerLegemiddel++;
          }
        }
        //lmliste.printAlle();
      }
      //Legger inn leger
      else if(info[1].compareTo("Leger") == 0){
        while(scanner.hasNextLine()){
          innlest = scanner.nextLine();
          //Om vi er ferdig med å legge til leger, bryt whileløkken,
          //slik at vi fortsetter til koden for å legge til resepter
          if(innlest.charAt(0) == '#'){
            break;
          }
          info = innlest.split(", ");
          int kontrollid = Integer.parseInt(info[1]);
          if(kontrollid == 0){
            String[] lInfo = innlest.split(",");
            String navn = lInfo[0];
            leggTilLege(navn);
          }
          else {
            String[] sInfo = innlest.split(",");
            String navn = sInfo[0];
            int kid = Integer.parseInt(sInfo[1].trim());
            leggTilSpesialist(navn, kid);
          }
        }
      }
      //Legger inn Resepter
      else if(info[1].compareTo("Resepter") == 0){
        Pasient pasient = null;
        Legemiddel legemiddel = null;
        Lege lege = null;
        Spesialister spesialist = null;
        int legeMiddelnr = 0;
        String legeNavn = "";
        int reit = 0;
        int pasientID = 0;
        while(scanner.hasNextLine()){
          innlest = scanner.nextLine();
          info = innlest.split(",");
          legeMiddelnr = Integer.parseInt(info[0].trim());
          legeNavn = info[1];
          pasientID = Integer.parseInt(info[2].trim());
          reit = Integer.parseInt(info[3].trim());

          for(Pasient p : pasientliste) {
            if(p.hentPid() == pasientID) {
              pasient = p;
            }
          }

          for(Legemiddel lm : lmliste) {
            if(0 < legeMiddelnr) {
              legemiddel = lm;
            }
          }

          for(Lege l : legeliste) {
            if(l.hentNavn().equals(legeNavn)) {
              lege = l;
            }
            else if(l instanceof Spesialister) {
              lege = l;
            }
          }

          Resept r = lege.skrivResept(legemiddel, lege, pasient, reit);
          pasient.leggTilResept(r);
          lege.leggTilResept(r);
          utskrevendeResept.leggTil(r);
        } //end of while
      }
    }
  }

  public static void leggTilPasient(String navn, String fnr, int pid) {
    Pasient ny = new Pasient(navn, fnr, pid);
    pasientliste.leggTil(ny);
  }

  public static void leggTilA(String navn, String type, double pris, double virkestoff, String ns) {
    PreaparatA a = new PreaparatA(navn, type, pris, virkestoff, ns);
    lmliste.leggTil(a);
  }
  public static void leggTilB(String navn, String type, double pris, double virkestoff, String vs) {
    PreaparatB b = new PreaparatB(navn, type, pris, virkestoff, vs);
    lmliste.leggTil(b);
  }
  public static void leggTilC(String navn, String type, double pris, double virkestoff) {
    PreaparatC c = new PreaparatC(navn, type, pris, virkestoff);
    lmliste.leggTil(c);
  }

  public static void leggTilLege(String navnTilLege) {
    Lege l = new Lege(navnTilLege);
    legeliste.leggTil(l);
  }

  public static void leggTilSpesialist(String navnTilLege, int kontrollId) {
    Spesialister s = new Spesialister(navnTilLege, kontrollId);
    legeliste.leggTil(s);
  }

} //end of class
