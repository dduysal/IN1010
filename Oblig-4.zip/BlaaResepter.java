public class BlaaResepter extends Resept {
  public BlaaResepter(Legemiddel legemiddel, Lege utskrivendeLege, Pasient pasient, int reit) {
    super(legemiddel, utskrivendeLege, pasient, reit);
  }

  public String farge() {
    return "blaa";
  }

  public double prisAaBetale() {
    double nyPris = (legemiddel.hentPris() * 75) / 100;
    return legemiddel.settNyPris(nyPris);
  }

}
