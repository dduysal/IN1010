public class PreaparatA extends Legemiddel {
  private int narkotiskStyrke;

  public PreaparatA(String navn, double pris, double virkestoff, int Id,  int ns) {
    super(navn, pris, virkestoff, Id);
    this.narkotiskStyrke = ns;
  }

  public int hentNarkotiskStyrke(){
    return narkotiskStyrke;
  }

 }
