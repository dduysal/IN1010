public class HviteResepter extends Resepter {
  public HviteResepter(Legemiddel legemiddel, Lege utskrivendeLege, int pasientId, int reit) {
    super(legemiddel, utskrivendeLege, pasientId, reit);
  }

  public String farge() {
    return "hvit";
  }

  public double prisAaBetale() {
    if(this instanceof MillitaerResepter) {
      System.out.println("Prisen for en MillitaerResepter er: ");
      return new MillitaerResepter(legemiddel, utskrivendeLege, pasientId, reit).prisAaBetaleMillitaerResepter();
    } else if(this instanceof P_Resepter) {
      System.out.println("Prisen for en P_Respet er: ");
      return new P_Resepter(legemiddel, utskrivendeLege, pasientId, reit).prisAaBetaleP_Resepter();
    } else {
      return 0.0;
    }
  }
}
