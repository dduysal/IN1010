public class SortRute extends Rute {

public SortRute(int r, int k, Labyrint lab) {
    super(r, k, lab);
  }


  public String tilTegn() {
    return "#";
  }

  public void gaa(String t) {
    return;
  }

}
