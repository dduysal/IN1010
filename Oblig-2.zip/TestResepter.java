public class TestResepter {
  public static void main(String[] args) {
    Legemiddel lm = new Legemiddel("Ibux", 200, 100.0, 2);
    Lege l = new Lege("Derya");
    HviteResepter hr = new HviteResepter(lm, l, 4, 2);

    System.out.println("2: " + hr.hentId());
    System.out.println("Legemiddel Ibux: " + hr.hentLegeMiddel().hentNavn());
    System.out.println("Lege " + hr.hentLege());
    System.out.println("pasientID: " + hr.hentPasientId());
    System.out.println("reit: " + hr.hentReit());
    System.out.println("bruk: " + hr.bruk());
    System.out.println("hvit: " + hr.farge());
    System.out.println("pris: " + hr.prisAaBetale());

    BlaaResepter br = new BlaaResepter(lm, l, 4, 2);
    System.out.println(br.prisAaBetale());

    MillitaerResepter mr = new MillitaerResepter(lm, l, 4, 2);
    System.out.println("mr betale: " + mr.prisAaBetaleMillitaerResepter());

    P_Resepter pr = new P_Resepter(lm, l, 4, 3);
    System.out.println("pr betale: " + pr.prisAaBetaleP_Resepter());



  }
}
