import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;

public class Oblig6 {
  public static void main(String[] args) {
    int antTelegrafister = 3;
    int antKryptografer = 10;
    Operasjonssentral ops = new Operasjonssentral(3);
    Kanal[] kanaler = ops.hentKanalArray();
    Kryptert_Monitor krypte = new Kryptert_Monitor();
    Dekryptert_Monitor dekrypte = new Dekryptert_Monitor();

    for(int i =  0; i < antTelegrafister; i++) {
      new Thread (new Telegrafi(kanaler[i], krypte)).start();
    }

    for(int j =  0; j < antKryptografer; j++) {
      new Thread(new Kryptografer(dekrypte, krypte)).start();
    }


    new Thread(new Operasjonsleder(dekrypte, ops)).start();



  } //end of main
} //end of class
