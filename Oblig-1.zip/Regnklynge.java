import java.util.*;
import java.io.*;
public class Regnklynge {
  ArrayList<Rack> rackliste = new ArrayList<Rack>();
  int antNodePrRack;
  int antNoder;


  public Regnklynge(int antNodePrRack) {
    this.antNodePrRack = antNodePrRack;
  }

  public Regnklynge(String filnavn) throws FileNotFoundException {
    Scanner scan = new Scanner(new File(filnavn));
    antNodePrRack = scan.nextInt();
    String linje = scan.nextLine();
    while(scan.hasNextLine()) {
      String [] split = scan.nextLine().split(" ");
      antNoder = Integer.parseInt(split[0]);
      int minnePrNode = Integer.parseInt(split[1]);
      int antProsessorPrNode = Integer.parseInt(split[2]);
      Rack r = new Rack(antNoder);
      for(int i = 0; i < r.hentAntNode(); i++) {
        Node ny = new Node(minnePrNode, antProsessorPrNode);
        settInnNode(ny);
      }
    }
  }

  public void settInnNode(Node n) {
    if(rackliste.isEmpty()) {
      rackliste.add(new Rack(antNoder));
    } else {
      Rack ny = new Rack(antNoder);
      ny.settInnNode(n);
      rackliste.add(ny);
    }
  }

  public int hentAntNode() {
    return antNoder;
  }

  public int antProsessorer() {
    int antall = 0;
    for(int i = 0; i < rackliste.size(); i++) {
      antall = rackliste.get(i).antProsessorer();
    }
    return antall;
  }

  //Beregner antall noder i racket med minne over gitt grense
  public int noderMedNokMinne(int paakrevdMinne) {
    int antall = 0;
    for(int i = 0; i < rackliste.size(); i++) {
      antall = rackliste.get(i).noderMedNokMinne(paakrevdMinne);
    }
    return antall;
  }

  public int antRacks() {
    return rackliste.size();
  }

}//end of class
